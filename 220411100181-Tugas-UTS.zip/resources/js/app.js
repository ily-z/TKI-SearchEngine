import 'bootstrap';
import '../css/app.css'; // Your custom CSS (optional)